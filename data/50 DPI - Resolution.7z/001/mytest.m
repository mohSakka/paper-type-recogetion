
image=imread('01-1.jpg');
croppedImage = imcrop(image, [1, 1, 50, 50]);